#!/bin/sh
supervisord -c supervisord.conf

python3 app.py &

# DEPENDENCES
import os
from flask import Flask, request, jsonify
from celery import Celery
from flask_cors import CORS
import shutil
import zipfile
import subprocess
from datetime import datetime

# CONFIG
app = Flask(__name__)
app.config['CELERY_BROKER_URL'] = 'redis://localhost:6379/0'
app.config['CELERY_RESULT_BACKEND'] = 'redis://localhost:6379/0'
CORS(app, origins='*')
celery = Celery(app.name, broker=app.config['CELERY_BROKER_URL'])
celery.conf.update(app.config)

# Extraction de ZIP
@celery.task(bind=True)
def extract_zip(self, filename, username, root):
    progress_percent = 0
    # Mise à jour du pourcentage
    self.update_state(state='PENDING', meta={'progress_percent': progress_percent})

    # Extraction, màj du pourcentage en fonction de l'index du fichier en cours de copie, suppression du fichier temp
    temp_path = f'/home/{username}/temp.zip'
    extract_path = f'/home/{username}/{root}'
    with zipfile.ZipFile(filename, 'r') as zip_ref:
        total_files = len(zip_ref.namelist())
        for index, file in enumerate(zip_ref.namelist()):
            zip_ref.extract(file, extract_path)
            progress_percent = round((index+1)/total_files * 100, 2)
            self.update_state(state='PROGRESS', meta={'progress_percent': progress_percent})

    os.remove(filename)
    self.update_state(state='SUCCESS', meta={'message': 'Upload and unzip done', 'progress_percent': 100})

# Upload ZIP
@app.route('/api/upload', methods=['POST'])
def upload():
    # Params POST Formulaire
    file = request.files['file']
    username = request.form.get('username')
    root = request.form.get('root')

    file.save(f'/home/{username}/temp.zip')
    task = extract_zip.apply_async(args=[f'/home/{username}/temp.zip', username, root])
    # Retour du statut
    return jsonify({'task_id': task.id}), 202

# Stockage Libre
@app.route('/api/storage', methods=['POST'])
def storage():
    username = request.json.get("username", "u")
    output = subprocess.check_output(['df', '-h', f'/home/{username}'])
    output_lines = output.decode().split('\n')
    used_storage = output_lines[1].split()[2]
    total_storage = output_lines[1].split()[1]
    # Renvoi d'un JSON avec les valeurs stockage utilisé/total
    return jsonify({
        'used_storage': used_storage,
        'total_storage': total_storage
    })

# Execution du script initial.sh (route API)
@app.route('/api/setup', methods=['POST'])
def setup():
    task = run_setup.delay(request.json)
    return jsonify({'task_id': task.id}), 202

# Execution asynchrone du script
@celery.task(bind=True)
def run_setup(self, params):
    task_id = self.request.id
    progress_percent = 0
    total_steps = 11
    current_step = 0
    self.update_state(state='PENDING', meta={'progress_percent': progress_percent})
    
    # Params de l'utilisateur
    storage = params.get("storage", "100")
    user = params.get("user", "groupe14")
    dbpass = params.get("dbpass", "password")
    root = params.get("root", "www")
    domain = params.get("domain", "groupe14")
    
    # Lancement de la commande avec les flags associés
    cmd = f"./initial.sh --storage={storage} --user={user} --dbpass={dbpass} --root={root} --domain={domain}"
    
    # STDOUT : ligne renvoyée par la CLI
    process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    
    while True:
        line = process.stdout.readline()
        if not line:
            break
        current_step += 1
        progress_percent = int(current_step / total_steps * 100)
        self.update_state(state='PROGRESS', meta={'progress_percent': progress_percent})
    
    self.update_state(state='SUCCESS', meta={'progress_percent': 100,'message': 'Setup done'})
    
# Objet JSON renvoyant un statut
@app.route('/status/<task_id>')
def taskstatus(task_id):
    task = extract_zip.AsyncResult(task_id)
    if task.state == 'PENDING':
        response = {
            'state': task.state,
            'progress_percent': 0
        }
    elif task.state != 'FAILURE':
        response = {
            'state': task.state,
            'progress_percent': task.info.get('progress_percent', 0)
        }
        if 'message' in task.info:
            response['message'] = task.info['message']
        if 'result' in task.info:
            response['result'] = task.info['result']
    else:
        response = {
            'state': task.state,
            'progress_percent': 0,
            'message': str(task.info)
        }
    return jsonify(response)

if __name__ == "__main__":
        # for debugging locally
        app.run(debug=True, host='0.0.0.0',port=25565)

        # for production
        #app.run(host='0.0.0.0', port=5000)

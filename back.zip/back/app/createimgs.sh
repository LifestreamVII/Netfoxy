#!/bin/bash

dd if=/dev/zero of=/media/users/base100.img bs=1M count=100
mkfs.ext4 /media/users/base100.img
mkdir -p /mnt/100mb
mount -o loop /media/users/base100.img /mnt/100mb
mkdir -p /mnt/100mb/nginx
cp /home/lois/config/nginx/default /mnt/100mb/nginx/default
mkdir -p /mnt/100mb/www
umount /mnt/100mb
rm -rf /mnt/100mb

dd if=/dev/zero of=/media/users/base500.img bs=1M count=500
mkfs.ext4 /media/users/base500.img
mkdir -p /mnt/500mb
mount -o loop /media/users/base500.img /mnt/500mb
mkdir -p /mnt/500mb/nginx
cp /home/lois/config/nginx/default /mnt/500mb/nginx/default
mkdir -p /mnt/500mb/www
umount /mnt/500mb
rm -rf /mnt/500mb

dd if=/dev/zero of=/media/users/base1024.img bs=1M count=1000
mkfs.ext4 /media/users/base1024.img
mkdir -p /mnt/1gb
mount -o loop /media/users/base1024.img /mnt/1gb
mkdir -p /mnt/1gb/nginx
cp /home/lois/config/nginx/default /mnt/1gb/nginx/default
mkdir -p /mnt/1gb/www
umount /mnt/1gb
rm -rf /mnt/1gb

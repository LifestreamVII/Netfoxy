#!/bin/bash

# Val. par défaut
storage="100"
user="default1"
dbpass="password"
root="www"
domain="user1"

# Recup des flags
for arg in "$@"
do
    case $arg in
        --storage=*)
        storage="${arg#*=}"
        shift
        ;;
        --user=*)
        user="${arg#*=}"
        shift
        ;;
        --dbpass=*)
        dbpass="${arg#*=}"
        shift
        ;;
        --root=*)
        root="${arg#*=}"
        shift
        ;;
        --domain=*)
        domain="${arg#*=}"
        shift
        ;;
        *) # Unknown option
        echo "Unknown option: $arg"
        exit 1
        ;;
    esac
done
#if false; then

# Copie de la base d'image contenant la config par défaut
cp /media/users/base"${storage}".img /media/users/"${user}".img

# MDP encrypté
password="${dbpass}"
salt=$(openssl rand -hex 6)
encrypted=$(openssl passwd -6 -salt "$salt" "$password")

# Ajout de l'utilisateur dans le groupe clients
useradd -m -p "$encrypted" "${user}"
usermod -a -G clients "${user}"

# Montage de son image dans son home dir
mount -o loop /media/users/"${user}".img /home/"${user}"

# + MAJ FSTAB en cas de reboot

# Remplacement de placeholders
sed -i "s/PUT_ROOT_HERE/\/home\/${user}\/${root}/g" /home/"${user}"/nginx/default
sed -i 's/PUT_INDEX_HERE/index index.html index.htm/g' /home/"${user}"/nginx/default
sed -i "s/PUT_DOMAIN_HERE/${domain}/g" /home/"${user}"/nginx/default
if [ "$root" == "www" ]; then
    echo "WWW created"
else
    echo "Custom dir created"
    mkdir -p /home/"${user}"/"${root}"
fi

# Changement du propriétaire
chown -R "${user}":clients /home/"${user}" /home/"${user}"/nginx /home/"${user}"/nginx/default

# Création de BDD/User MySQL
mysql -h localhost -u root -e "CREATE DATABASE ${user}; CREATE USER '${user}'@'localhost' IDENTIFIED BY '${dbpass}'; GRANT ALL PRIVILEGES ON ${user}.* TO '${user}'@'localhost';"

# reboot NGINX
systemctl restart nginx


#fi
